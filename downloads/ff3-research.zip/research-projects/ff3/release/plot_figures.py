"""Portable FF3-only presentation renderer. No raw data or other projects.

Uses the same FF3 rendering functions as scripts/build_figures.py at finalization.
Writes only to a newly created --out directory; accepted tables remain read-only.
"""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

ROOT = Path(__file__).resolve().parent
FIG = DATA = PREVIEW = None

INK = "#0F2340"
BLUE = "#2457C5"
TEAL = "#0E8F87"
AMBER = "#C27A12"
RED = "#B4413C"
GRID = "#E3E1DA"
MUTED = "#6B7385"
SHADE = "#E9E4D8"

plt.rcParams.update(
    {
        "font.family": ["Source Sans 3", "Segoe UI", "DejaVu Sans"],
        "font.size": 10.5,
        "axes.edgecolor": "#9AA1AE",
        "axes.labelcolor": INK,
        "axes.titlecolor": INK,
        "axes.titlesize": 11.5,
        "axes.titleweight": 600,
        "axes.titlelocation": "left",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.color": GRID,
        "grid.linewidth": 0.7,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "legend.frameon": False,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.12,
        "svg.fonttype": "path",
    }
)

SIZE_LABELS = ["S1 (Small)", "S2", "S3", "S4", "S5 (Big)"]
BM_LABELS = ["B1 (Low)", "B2", "B3", "B4", "B5 (High)"]


def save(fig: plt.Figure, rel: str) -> None:
    out = FIG / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    if rel.startswith("ff3/"):
        # Stable presentation artifacts; no timestamp/random SVG IDs or trailing spaces.
        with matplotlib.rc_context({"svg.hashsalt": "ff3-r01-final"}):
            fig.savefig(out, format="svg", metadata={"Date": None})
        out.write_text("\n".join(line.rstrip() for line in out.read_text(encoding="utf-8").splitlines()) + "\n", encoding="utf-8")
    else:
        fig.savefig(out, format="svg")
    if PREVIEW:
        png = PREVIEW / rel.replace("/", "__").replace(".svg", ".png")
        png.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(png, format="png", dpi=110)
    plt.close(fig)
    print("figure", out.name)


def dump(name: str, payload: dict) -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    out = DATA / f"{name}.json"
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    print("data  ", out.relative_to(ROOT))


def shade_runs(ax, dates: pd.Series, mask: pd.Series, **kw) -> None:
    mask = mask.astype(bool).to_numpy()
    dates = pd.to_datetime(dates).to_numpy()
    start = None
    for i, flag in enumerate(mask):
        if flag and start is None:
            start = i
        if start is not None and (not flag or i == len(mask) - 1):
            end = i if flag else i - 1
            right = dates[end + 1] if end + 1 < len(dates) else dates[end]
            ax.axvspan(dates[start], right, color=SHADE, lw=0, zorder=0, **kw)
            start = None


def records(df: pd.DataFrame) -> list[dict]:
    return json.loads(df.to_json(orient="records", date_format="iso"))


# --------------------------------------------------------------------------- FF3


def build_ff3() -> None:
    t = ROOT / "tables"
    factors = pd.read_csv(t / "ff3_factor_monthly.csv")
    factors["month"] = pd.PeriodIndex(factors["month"], freq="M").to_timestamp()
    reg = pd.read_csv(t / "capm_ff3_hac_regressions_baseline.csv")
    summary = pd.read_csv(t / "model_comparison_summary.csv")
    grs = pd.read_csv(t / "grs_test.csv")
    rf_rob = pd.read_csv(t / "rf_convention_robustness_comparison.csv")
    counts25 = pd.read_csv(t / "test25_monthly_stock_counts.csv")
    counts6 = pd.read_csv(t / "six_portfolio_monthly_stock_counts.csv")

    # Figure 1: cumulative factor returns
    fig, ax = plt.subplots(figsize=(9.2, 3.9))
    for col, label, color in [("MKT_RF", "MKT − RF", INK), ("SMB", "SMB", BLUE), ("HML", "HML", TEAL)]:
        ax.plot(factors["month"], (1 + factors[col]).cumprod(), label=label, color=color, lw=1.8)
    ax.axhline(1, color="#9AA1AE", lw=0.8)
    ax.set_ylabel("Illustrative factor index (not investable NAV)")
    ax.set_title("Cumulative factor returns, 2017-07 to 2024-11 (T = 89)")
    ax.legend(ncol=3, loc="upper left")
    save(fig, "ff3/factor_cumulative.svg")

    # Figure 2: adjusted R² dumbbell
    pv = reg.pivot(index="portfolio", columns="model", values="adj_r2")
    order = [f"S{s}B{b}" for s in range(1, 6) for b in range(1, 6)]
    pv = pv.loc[order]
    x = np.arange(len(order))
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    ax.vlines(x, pv["CAPM"], pv["FF3"], color="#B9C3D6", lw=2, zorder=1)
    ax.scatter(x, pv["CAPM"], color=AMBER, s=30, zorder=2, label="CAPM")
    ax.scatter(x, pv["FF3"], color=BLUE, s=30, zorder=3, label="FF3")
    for k in range(1, 5):
        ax.axvline(5 * k - 0.5, color=GRID, lw=1)
    ax.set_xticks(x, order, rotation=90, fontsize=8.5)
    ax.set_ylim(0.4, 1.0)
    ax.set_ylabel("Adjusted R²")
    ax.set_title("Adjusted R² by test portfolio (grouped by size quintile)")
    ax.legend(loc="lower right", ncol=2)
    ax.grid(axis="x", visible=False)
    save(fig, "ff3/adj_r2_dumbbell.svg")

    # Figure 3: alpha heatmaps
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.0))
    vmax = float(np.abs(reg["alpha"]).max() * 100)
    cmap = LinearSegmentedColormap.from_list("div", [TEAL, "#F5F4F0", RED])
    for ax, model in zip(axes, ["CAPM", "FF3"]):
        d = reg[reg["model"] == model].set_index("portfolio").loc[order]
        a = (d["alpha"].to_numpy() * 100).reshape(5, 5)
        tv = d["alpha_t"].to_numpy().reshape(5, 5)
        pval = d["alpha_p"].to_numpy().reshape(5, 5)
        im = ax.imshow(a, cmap=cmap, norm=TwoSlopeNorm(0, -vmax, vmax))
        for i in range(5):
            for j in range(5):
                star = "*" if pval[i, j] < 0.05 else ""
                dark = abs(a[i, j]) > 0.55 * vmax
                ax.text(j, i - 0.12, f"{a[i, j]:.2f}{star}", ha="center", va="center", fontsize=9, color="white" if dark else INK)
                ax.text(j, i + 0.22, f"z={tv[i, j]:.1f}", ha="center", va="center", fontsize=7.2, color="#F3F1EC" if dark else MUTED)
        ax.set_xticks(range(5), ["B1", "B2", "B3", "B4", "B5"])
        ax.set_yticks(range(5), ["S1", "S2", "S3", "S4", "S5"])
        ax.set_xlabel("Book-to-market: Low → High")
        ax.set_title(f"{model} α (% / month)")
        ax.grid(False)
        for s in ax.spines.values():
            s.set_visible(False)
    axes[0].set_ylabel("Size: Small → Big")
    fig.suptitle("Pointwise HAC(6): * unadjusted p < 0.05 | FF3 Holm: 0; BH: 2", fontsize=10)
    fig.colorbar(im, ax=axes, shrink=0.8, label="α, % per month")
    save(fig, "ff3/alpha_heatmaps.svg")

    # Figure 4: FF3 loadings
    d = reg[reg["model"] == "FF3"].set_index("portfolio").loc[order]
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.4))
    specs = [("beta_mkt", "β MKT", "Blues"), ("beta_smb", "β SMB", None), ("beta_hml", "β HML", None)]
    for ax, (col, title, cm) in zip(axes, specs):
        m = d[col].to_numpy().reshape(5, 5)
        if cm:
            ax.imshow(m, cmap=LinearSegmentedColormap.from_list("seq", ["#F5F4F0", BLUE]), vmin=0.6, vmax=1.2)
        else:
            lim = float(np.abs(m).max())
            ax.imshow(m, cmap=LinearSegmentedColormap.from_list("div2", [AMBER, "#F5F4F0", BLUE]), norm=TwoSlopeNorm(0, -lim, lim))
        for i in range(5):
            for j in range(5):
                ax.text(j, i, f"{m[i, j]:.2f}", ha="center", va="center", fontsize=8.5, color=INK)
        ax.set_xticks(range(5), ["B1", "B2", "B3", "B4", "B5"])
        ax.set_yticks(range(5), ["S1", "S2", "S3", "S4", "S5"])
        ax.set_title(title)
        ax.grid(False)
        for s in ax.spines.values():
            s.set_visible(False)
    fig.suptitle("FF3 factor loadings across the 5×5 Size × B/M grid", x=0.01, ha="left", fontsize=11.5, fontweight=600, color=INK)
    save(fig, "ff3/loadings.svg")

    # Figure 5: portfolio coverage
    counts25["month"] = pd.PeriodIndex(counts25["month"], freq="M").to_timestamp()
    counts6["month"] = pd.PeriodIndex(counts6["month"], freq="M").to_timestamp()
    s0, s1 = pd.Timestamp("2017-07-01"), pd.Timestamp("2024-11-01")
    c25 = counts25[counts25["month"].between(s0, s1)]
    c6 = counts6[counts6["month"].between(s0, s1)]
    total = c6.groupby("month")["n_stocks"].sum()
    min25 = c25.groupby("month")["n_stocks"].min()
    fig, ax = plt.subplots(figsize=(9.2, 3.0))
    ax.plot(total.index, total.values, color=INK, lw=1.8, label="Stocks in the six 2×3 portfolios")
    ax2 = ax.twinx()
    ax2.plot(min25.index, min25.values, color=TEAL, lw=1.5, label="Smallest 5×5 portfolio")
    ax2.spines["right"].set_visible(True)
    ax2.grid(False)
    ax.set_ylabel("Stocks", color=INK)
    ax2.set_ylabel("Stocks (min cell)", color=TEAL)
    ax.set_title("Cross-sectional coverage by month")
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper left")
    save(fig, "ff3/coverage.svg")

    # Inference and page numbers come from the accepted, verified final release.
    # Do not reconstruct a legacy JSON here: this would silently discard Holm/BH.
    shutil.copyfile(ROOT / "display.json", DATA / "ff3.json")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    DATA = args.out
    FIG = args.out / "figures"
    PREVIEW = args.out / "preview"
    build_ff3()
