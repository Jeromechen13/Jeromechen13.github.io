"""Independent implementation workspace; never imports or executes the original notebook."""
