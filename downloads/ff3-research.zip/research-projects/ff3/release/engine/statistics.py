"""OLS/HAC and classical GRS. R01 changes only the selected GRS normalization."""
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats


def model_inputs(portfolios, factors, model, convention):
    rf = 'rf' if convention == 'start' else 'rf_end'
    mk = 'MKT_RF' if convention == 'start' else 'MKT_RF_end'
    cols = [mk] if model == 'CAPM' else [mk, 'SMB', 'HML']
    if not portfolios.index.equals(factors.index):
        raise ValueError('Portfolio/factor months are not identical')
    if portfolios.isna().any().any() or factors[cols + [rf]].isna().any().any():
        raise ValueError('Incomplete common monthly panel')
    return portfolios.sub(factors[rf], axis=0), factors[cols]


def regressions(portfolios, factors, config):
    rows, coefficients = [], []
    for asset in portfolios:
        for model in ['CAPM', 'FF3']:
            for conv in ['start', 'end']:
                Y, F = model_inputs(portfolios, factors, model, conv)
                X = sm.add_constant(F)
                fit = sm.OLS(Y[asset], X).fit(cov_type='HAC', cov_kwds={'maxlags': config['hac_lags'], 'kernel': config['hac_kernel'], 'use_correction': config['hac_use_correction']}, use_t=config['hac_use_t'])
                plain = sm.OLS(Y[asset], X).fit()
                mk = F.columns[0]
                rows.append(dict(portfolio=asset, model=model, rf_convention=conv, nobs=int(fit.nobs),
                                 alpha=fit.params['const'], alpha_t=fit.tvalues['const'], alpha_p=fit.pvalues['const'], adj_r2=fit.rsquared_adj,
                                 beta_mkt=fit.params[mk], beta_smb=fit.params.get('SMB', np.nan), beta_hml=fit.params.get('HML', np.nan)))
                for param in X.columns:
                    ci = fit.conf_int().loc[param]
                    coefficients.append(dict(portfolio=asset, model=model, rf_convention=conv, parameter=param,
                                             coefficient=fit.params[param], HAC_se=fit.bse[param], HAC_statistic=fit.tvalues[param], HAC_p_normal=fit.pvalues[param],
                                             OLS_se=plain.bse[param], OLS_t=plain.tvalues[param], OLS_p_student=plain.pvalues[param],
                                             ci_lower=ci.iloc[0], ci_upper=ci.iloc[1], r2=fit.rsquared, adj_r2=fit.rsquared_adj))
    return pd.DataFrame(rows), pd.DataFrame(coefficients)


def grs_value(Y, F, mode='legacy'):
    Y, F = np.asarray(Y, dtype=float), np.asarray(F, dtype=float)
    if Y.ndim == 1:
        Y = Y[:, None]
    if F.ndim == 1:
        F = F[:, None]
    T, N, K = len(Y), Y.shape[1], F.shape[1]
    if T != len(F) or T <= N + K or not np.isfinite(Y).all() or not np.isfinite(F).all():
        raise ValueError('GRS requires finite aligned observations and T > N + K')
    X = sm.add_constant(F, has_constant='add')
    if np.linalg.matrix_rank(X) < K + 1:
        raise ValueError('Singular design')
    fits = [sm.OLS(Y[:, j], X).fit() for j in range(N)]
    alpha = np.array([fit.params[0] for fit in fits])
    E = np.column_stack([fit.resid for fit in fits])
    mu = F.mean(axis=0)
    se = E.T @ E / (T - K - 1)
    sf = np.atleast_2d(np.cov(F, rowvar=False, ddof=1))
    if np.linalg.matrix_rank(se) < N or np.linalg.matrix_rank(sf) < K:
        raise ValueError('Singular covariance')
    qa = alpha @ np.linalg.solve(se, alpha)
    qf = mu @ np.linalg.solve(sf, mu)
    if mode not in ('legacy', 'exact'):
        raise ValueError('Unknown GRS formula')
    denominator = 1 + qf if mode == 'legacy' else 1 + T / (T - 1) * qf
    value = T / N * (T - N - K) / (T - K - 1) * qa / denominator
    return dict(T=T, N=N, K=K, GRS=value, df1=N, df2=T-N-K, p_value=stats.f.sf(value, N, T-N-K))


def grs_table(portfolios, factors, mode):
    rows = []
    for conv in ['start', 'end']:
        for model in ['CAPM', 'FF3']:
            Y, F = model_inputs(portfolios, factors, model, conv)
            rows.append(dict(rf_convention=conv, model=model, **grs_value(Y, F, mode)))
    return pd.DataFrame(rows)


def summary_tables(reg, factors, grs):
    summary = reg.groupby(['rf_convention', 'model']).agg(
        portfolios=('portfolio', 'nunique'), avg_adj_r2=('adj_r2', 'mean'), median_adj_r2=('adj_r2', 'median'),
        mean_abs_alpha=('alpha', lambda x: np.mean(np.abs(x))), median_abs_alpha=('alpha', lambda x: np.median(np.abs(x))),
        significant_alpha_5pct=('alpha_p', lambda x: np.sum(x < .05)))
    summary['avg_adj_r2_pct'] = summary.avg_adj_r2 * 100
    summary['mean_abs_alpha_pct_month'] = summary.mean_abs_alpha * 100
    start = reg[reg.rf_convention == 'start'].copy()
    end = reg[reg.rf_convention == 'end'].copy()
    robust = start.merge(end, on=['portfolio', 'model'], suffixes=('_start', '_end'))
    robust['alpha_diff_bp'] = (robust.alpha_end - robust.alpha_start) * 10000
    robust['adj_r2_diff'] = robust.adj_r2_end - robust.adj_r2_start
    capm, ff3 = summary.loc[('start', 'CAPM')], summary.loc[('start', 'FF3')]
    g = grs.set_index(['rf_convention', 'model'])
    metrics = pd.Series({
        'CAPM avg adjusted R2': capm.avg_adj_r2, 'FF3 avg adjusted R2': ff3.avg_adj_r2,
        'FF3 minus CAPM avg adjusted R2': ff3.avg_adj_r2 - capm.avg_adj_r2,
        'CAPM mean abs alpha (%/month)': capm.mean_abs_alpha * 100,
        'FF3 mean abs alpha (%/month)': ff3.mean_abs_alpha * 100,
        'Alpha reduction (%)': (1 - ff3.mean_abs_alpha / capm.mean_abs_alpha) * 100,
        'SMB mean (%/month)': factors.SMB.mean() * 100, 'HML mean (%/month)': factors.HML.mean() * 100,
        'CAPM GRS p-value': g.loc[('start', 'CAPM'), 'p_value'], 'FF3 GRS p-value': g.loc[('start', 'FF3'), 'p_value']})
    metrics.index.name = 'metric'
    return {'capm_ff3_hac_regressions_all_rf_conventions.csv': reg,
            'capm_ff3_hac_regressions_baseline.csv': start,
            'capm_ff3_hac_regressions_rf_end_robustness.csv': end,
            'rf_convention_robustness_comparison.csv': robust,
            'model_comparison_summary.csv': summary.reset_index(),
            'grs_test.csv': grs, 'resume_metrics.csv': metrics.rename('value').reset_index()}
