"""v7 data cleaning, including known limitations intentionally retained for R00/R01."""
from pathlib import Path
import numpy as np
import pandas as pd


def read_csv(path, stock_code=False):
    for enc in ['utf-8-sig', 'utf-8', 'gb18030', 'gbk']:
        try:
            return pd.read_csv(path, encoding=enc, dtype={'Stkcd': str} if stock_code else None, low_memory=False)
        except UnicodeDecodeError:
            continue
    raise UnicodeError(f'Unable to decode {path}')


def load_and_clean(workspace, config):
    raw = {k: read_csv(p, k in ('stock', 'finance')) for k, p in workspace['raw_files'].items()}
    quality = []
    for k, d in raw.items():
        quality.append({'table': k, 'rows': len(d), 'memory_bytes': int(d.memory_usage(deep=True).sum()),
                        'path': workspace['raw_files'][k]})
    monthly, financials, market, rf_raw = [raw[k] for k in ('stock', 'finance', 'market', 'rf')]
    for d in [monthly, financials]:
        d['Stkcd'] = d.Stkcd.str.zfill(6)
    monthly['month'] = pd.to_datetime(monthly.Trdmnt, format='%Y-%m').dt.to_period('M')
    market['month'] = pd.to_datetime(market.Trdmnt, format='%Y-%m').dt.to_period('M')
    financials['Accper'] = pd.to_datetime(financials.Accper, errors='coerce')
    rf_raw['Clsdt'] = pd.to_datetime(rf_raw.Clsdt, errors='coerce')
    rf_raw['month'] = rf_raw.Clsdt.dt.to_period('M')
    stock = monthly[monthly.month.between(config['raw_start'], config['raw_end']) & monthly.Markettype.isin(config['market_types'])].copy()
    for c in ['Mretwd', 'Msmvttl', 'Msmvosd', 'Ndaytrd']:
        stock[c] = pd.to_numeric(stock[c], errors='coerce')
    if stock.duplicated(['Stkcd', 'month']).any():
        raise ValueError('Duplicate stock-month')
    me = stock[['Stkcd', 'month', 'Msmvttl', 'Msmvosd', 'Markettype']].dropna(subset=['Msmvttl']).copy()
    me = me[me.Msmvttl > 0].copy()
    ret = stock[['Stkcd', 'month', 'Mretwd', 'Ndaytrd', 'Markettype']].dropna(subset=['Mretwd']).copy()
    fin = financials[(financials.Typrep == 'A') & (financials.Accper.dt.month == 12) & (financials.Accper.dt.day == 31)].copy()
    fin['book_equity'] = pd.to_numeric(fin[config['book_equity']], errors='coerce')
    fin = fin.dropna(subset=['book_equity'])
    fin = fin[fin.book_equity > 0].copy()
    fin['fiscal_year'] = fin.Accper.dt.year
    if fin.duplicated(['Stkcd', 'fiscal_year']).any():
        raise ValueError('Duplicate consolidated year end financials')
    mr = market[(market.Markettype == config['composite_market_type']) & market.month.between(config['raw_start'], config['raw_end'])].copy()
    mr['mkt_ret'] = pd.to_numeric(mr.Cmretwdtl, errors='coerce')
    mr['mkt_ret_float'] = pd.to_numeric(mr.Cmretwdos, errors='coerce')
    # Intentionally retain original first-row convention (no duplicates in this vintage).
    mr = mr[['month', 'mkt_ret', 'mkt_ret_float']].drop_duplicates('month').set_index('month').sort_index()
    rf_raw['Nrrmtdt'] = pd.to_numeric(rf_raw.Nrrmtdt, errors='coerce')
    rf = rf_raw.dropna(subset=['month', 'Clsdt', 'Nrrmtdt']).sort_values('Clsdt').copy()
    # No new benchmark filter: original input has only NRI01.
    first = rf.drop_duplicates('month', keep='first')[['month', 'Nrrmtdt']].rename(columns={'Nrrmtdt': 'first'})
    last = rf.drop_duplicates('month', keep='last')[['month', 'Nrrmtdt']].rename(columns={'Nrrmtdt': 'last'})
    rfm = first.merge(last, on='month', how='outer').sort_values('month').set_index('month')
    rfm['rf'] = rfm['first'] / 100.0
    rfm['rf_end'] = rfm['last'] / 100.0
    return dict(raw=raw, stock=stock, me=me, ret=ret, fin=fin, mr=mr, rfm=rfm, quality=pd.DataFrame(quality))
