"""Annual independent sorts and exact-calendar-lag ME weights; no event repairs."""
import numpy as np
import pandas as pd

SIX = ['SL', 'SN', 'SH', 'BL', 'BN', 'BH']
TWENTY_FIVE = [f'S{s}B{b}' for s in range(1, 6) for b in range(1, 6)]


def form_characteristics(data, config):
    me, fin = data['me'], data['fin']
    june = me[me.month.dt.month == 6][['Stkcd', 'month', 'Msmvttl']].copy()
    june['formation_year'] = june.month.dt.year
    june = june.rename(columns={'Msmvttl': 'size_june_k_yuan'})
    dec = me[me.month.dt.month == 12][['Stkcd', 'month', 'Msmvttl']].copy()
    dec['fiscal_year'] = dec.month.dt.year
    dec = dec.rename(columns={'Msmvttl': 'me_dec_k_yuan'})
    bm = fin[['Stkcd', 'fiscal_year', 'book_equity']].merge(dec[['Stkcd', 'fiscal_year', 'me_dec_k_yuan']], on=['Stkcd', 'fiscal_year'], how='inner')
    bm['me_dec_yuan'] = bm.me_dec_k_yuan * config['bm_me_multiplier']
    bm['bm'] = bm.book_equity / bm.me_dec_yuan
    bm['formation_year'] = bm.fiscal_year + 1
    f = june[['Stkcd', 'formation_year', 'size_june_k_yuan']].merge(bm[['Stkcd', 'formation_year', 'book_equity', 'me_dec_yuan', 'bm']], on=['Stkcd', 'formation_year'], how='inner')
    return f[np.isfinite(f.bm) & (f.bm > 0) & (f.size_june_k_yuan > 0)].copy()


def assign_groups(formation):
    f = formation.copy()
    g = f.groupby('formation_year')
    f['size_median'] = g.size_june_k_yuan.transform('median')
    for name, q in [('bm30', .30), ('bm70', .70)]:
        f[name] = g.bm.transform(lambda x: x.quantile(q, interpolation='linear'))
    f['size2'] = np.where(f.size_june_k_yuan <= f.size_median, 'S', 'B')
    f['bm3'] = np.select([f.bm <= f.bm30, f.bm <= f.bm70], ['L', 'N'], default='H')
    f['port_2x3'] = f.size2 + f.bm3
    for label, q in [('20', .2), ('40', .4), ('60', .6), ('80', .8)]:
        f['size_q' + label] = g.size_june_k_yuan.transform(lambda x: x.quantile(q, interpolation='linear'))
        f['bm_q' + label] = g.bm.transform(lambda x: x.quantile(q, interpolation='linear'))
    for out, value, prefix in [('size5', 'size_june_k_yuan', 'size_q'), ('bm5', 'bm', 'bm_q')]:
        f[out] = 1 + sum((f[value] > f[prefix + k]).astype(int) for k in ['20', '40', '60', '80'])
    f['port_5x5'] = 'S' + f.size5.astype(str) + 'B' + f.bm5.astype(str)
    return f


def join_holdings(ret, me, assignments):
    h = ret[['Stkcd', 'month', 'Mretwd']].copy()
    h['formation_year'] = np.where(h.month.dt.month >= 7, h.month.dt.year, h.month.dt.year - 1)
    lag = me[['Stkcd', 'month', 'Msmvttl']].copy()
    lag['month'] += 1
    lag = lag.rename(columns={'Msmvttl': 'lag_me'})
    h = h.merge(lag, on=['Stkcd', 'month'], how='left')
    h = h.merge(assignments[['Stkcd', 'formation_year', 'port_2x3', 'port_5x5']], on=['Stkcd', 'formation_year'], how='inner')
    valid = h.dropna(subset=['Mretwd', 'lag_me']).copy()
    valid = valid[valid.lag_me > 0].copy()
    valid['weighted_ret'] = valid.Mretwd * valid.lag_me
    return h, valid


def aggregate(holding, key, columns, config):
    long = holding.groupby(['month', key], as_index=False).agg(weighted_ret_sum=('weighted_ret', 'sum'), weight_sum=('lag_me', 'sum'), n_stocks=('Stkcd', 'nunique'))
    long['ret'] = long.weighted_ret_sum / long.weight_sum
    long = long[long.month.between(config['sample_start'], config['sample_end'])].copy()
    wide = long.pivot(index='month', columns=key, values='ret').sort_index()[columns]
    return long, wide


def build(data, config):
    f = assign_groups(form_characteristics(data, config))
    assigned, valid = join_holdings(data['ret'], data['me'], f)
    long6, six = aggregate(valid, 'port_2x3', SIX, config)
    long25, p25 = aggregate(valid, 'port_5x5', TWENTY_FIVE, config)
    fac = pd.DataFrame(index=six.index)
    fac['SMB'] = six[['SL', 'SN', 'SH']].mean(axis=1, skipna=False) - six[['BL', 'BN', 'BH']].mean(axis=1, skipna=False)
    fac['HML'] = six[['SH', 'BH']].mean(axis=1, skipna=False) - six[['SL', 'BL']].mean(axis=1, skipna=False)
    fac = fac.join(data['mr'][['mkt_ret', 'mkt_ret_float']], how='inner').join(data['rfm'][['rf', 'rf_end']], how='inner')
    fac['MKT_RF'] = fac.mkt_ret - fac.rf
    fac['MKT_RF_end'] = fac.mkt_ret - fac.rf_end
    bpcols = [c for c in f if c.startswith(('size_q', 'bm_q'))] + ['size_median', 'bm30', 'bm70']
    breakpoints = f.groupby('formation_year')[bpcols].first().reset_index()
    breakpoints['n_stocks'] = f.groupby('formation_year').size().to_numpy()
    return dict(formation=f, assigned=assigned, valid=valid, six=six, p25=p25, long6=long6, long25=long25, factors=fac, breakpoints=breakpoints)
