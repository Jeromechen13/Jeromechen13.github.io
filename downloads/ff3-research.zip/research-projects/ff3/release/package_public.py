"""Publish only explicitly enumerated, hash-verified files; never recurse-copy."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, shutil, zipfile

def package(root, manifest_path, dest):
    root=Path(root).resolve(); dest=Path(dest).resolve(); manifest_path=Path(manifest_path).resolve()
    if dest==root or root in dest.parents:
        raise ValueError('Package destination must be outside source repository')
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    entries=manifest['files']; seen=set(); sources=[]
    for row in entries:
        rel=PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts or str(rel) in seen:
            raise ValueError('Invalid or duplicate allowed path')
        seen.add(str(rel))
        if any(x.lower() in {'audit','private','references','_deps','node_modules','.git'} for x in rel.parts):
            raise ValueError('Protected directory in publication list')
        if rel.name in {'TRD_Mnth.csv','FS_Combas.csv','TRD_Cnmont.csv','TRD_Nrrate.csv'}:
            raise ValueError('Licensed raw input in publication list')
        p=(root/str(rel)).resolve()
        if root not in p.parents or p.is_symlink(): raise ValueError('Path escapes source root')
        if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
            raise ValueError('Changed allowed file: '+str(rel))
        sources.append((p,str(rel)))
    # Manifest is explicitly named separately to avoid a self-referential digest.
    manifest_entry=manifest['manifest_entry']
    if (root/manifest_entry).resolve()!=manifest_path or manifest_entry in seen:
        raise ValueError('Invalid manifest entry')
    if dest.exists() or dest.with_suffix('.zip').exists(): raise FileExistsError(dest)
    dest.mkdir(parents=True)
    for src,rel in sources+[(manifest_path,manifest_entry)]:
        p=dest/rel; p.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,p)
    zpath=dest.with_suffix('.zip')
    with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for _,rel in sources+[(manifest_path,manifest_entry)]: z.write(dest/rel,rel)
    with zipfile.ZipFile(zpath) as z:
        expected=seen|{manifest_entry}
        if set(z.namelist())!=expected: raise ValueError('Unexpected archive contents')
        for row in entries:
            if hashlib.sha256(z.read(row['path'])).hexdigest()!=row['sha256']: raise ValueError('Archive hash mismatch')
    return {'files':len(entries)+1,'zip_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'zip':str(zpath)}

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--out',type=Path,required=True)
    args=p.parse_args(); here=Path(__file__).resolve().parent
    print(json.dumps(package(here.parents[2],here/'PUBLIC_ALLOWLIST.json',args.out),indent=2))
