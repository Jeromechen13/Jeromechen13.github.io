"""Post-estimation only: fixed 25-alpha families, HAC normal intervals, Holm/BH.

Does not estimate new factors, change coefficients, select models or tune lags.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import norm


def adjusted_pvalues(p):
    p = np.asarray(p, dtype=float)
    if p.ndim != 1 or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError('Finite probabilities required')
    n = len(p)
    order = np.argsort(p, kind='stable')
    ranked = p[order]
    holm = np.minimum(1., np.maximum.accumulate((n - np.arange(n)) * ranked))
    bh = np.minimum(1., np.minimum.accumulate((n * ranked / np.arange(1, n+1))[::-1])[::-1])
    out_h, out_b = np.empty(n), np.empty(n)
    out_h[order], out_b[order] = holm, bh
    return out_h, out_b


def alpha_inference(reg, coefficients):
    keys = ['portfolio', 'model', 'rf_convention']
    a = coefficients[coefficients.parameter.eq('const')].copy()
    a = reg.merge(a[keys + ['coefficient', 'HAC_se', 'HAC_p_normal', 'ci_lower', 'ci_upper']], on=keys, validate='one_to_one')
    if len(a) != 100 or a[keys].duplicated().any():
        raise ValueError('Expected all 100 model/RF/portfolio estimates')
    np.testing.assert_allclose(a.alpha, a.coefficient, atol=1e-14, rtol=0)
    np.testing.assert_allclose(a.alpha_p, a.HAC_p_normal, atol=1e-14, rtol=0)
    a['ci95_lower'] = a.alpha - norm.ppf(.975) * a.HAC_se
    a['ci95_upper'] = a.alpha + norm.ppf(.975) * a.HAC_se
    np.testing.assert_allclose(a[['ci95_lower','ci95_upper']], a[['ci_lower','ci_upper']], atol=1e-14, rtol=0)
    for (model, rf), g in a.groupby(['model','rf_convention']):
        if set(g.portfolio) != {f'S{s}B{b}' for s in range(1,6) for b in range(1,6)}:
            raise ValueError('Family must contain exactly 25 portfolios')
        a.loc[g.index, 'holm_p'], a.loc[g.index, 'bh_p'] = adjusted_pvalues(g.alpha_p)
        a.loc[g.index, 'family'] = f'{model}_{rf}_25alpha'
    for name, col in [('unadjusted','alpha_p'),('holm','holm_p'),('bh','bh_p')]:
        a[name+'_reject_5pct'] = a[col] < .05
    a['ci_scope'] = 'pointwise_normal_95pct_not_simultaneous'
    return a.drop(columns=['coefficient','HAC_p_normal','ci_lower','ci_upper'])


def build(tables):
    tables = Path(tables)
    reg = pd.read_csv(tables/'capm_ff3_hac_regressions_all_rf_conventions.csv', float_precision='round_trip')
    coeff = pd.read_csv(tables/'coefficient_statistics.csv', float_precision='round_trip')
    a = alpha_inference(reg, coeff)
    counts = a.groupby(['rf_convention','model'],sort=True).agg(
        portfolios=('portfolio','size'), unadjusted=('unadjusted_reject_5pct','sum'),
        holm=('holm_reject_5pct','sum'), bh=('bh_reject_5pct','sum')).reset_index()
    return a, counts


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--tables', type=Path, default=Path(__file__).parent/'tables')
    parser.add_argument('--out', type=Path, required=True, help='New directory; existing directories are rejected')
    args = parser.parse_args()
    a, counts = build(args.tables)
    args.out.mkdir(parents=True, exist_ok=False)
    a.to_csv(args.out/'alpha_inference.csv',index=False)
    counts.to_csv(args.out/'multiplicity_summary.csv',index=False)
    manifest = {'inputs': {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.tables/'capm_ff3_hac_regressions_all_rf_conventions.csv',args.tables/'coefficient_statistics.csv']}, 'family':'25 portfolios per model and RF convention; FF3/start primary; CAPM comparator; end sensitivity','coefficients_modified':False,'HAC':'Bartlett 6, no df correction, asymptotic normal','CI':'pointwise 95%, not simultaneous'}
    (args.out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
