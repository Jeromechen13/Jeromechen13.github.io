"""Portable frozen R01 reproduction. Requires separately licensed, identical CSVs.

All outputs go to a unique private run under --out; the public release is read-only.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, importlib.metadata, json, shutil, sys, traceback, uuid
import numpy as np
import pandas as pd
from engine import data, portfolios, statistics

ROOT=Path(__file__).resolve().parent
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--inputs',type=Path,required=True,help='JSON mapping stock, finance, market, rf to licensed CSV paths')
    parser.add_argument('--out',type=Path,required=True,help='Private output directory outside the release and original input directories')
    args=parser.parse_args()
    inputs=json.loads(args.inputs.read_text(encoding='utf-8-sig'))
    inputs={k:str(Path(v).resolve()) for k,v in inputs.items()}
    dest=args.out.resolve()
    if dest==ROOT or ROOT in dest.parents or any(dest==Path(v).parent or Path(v).parent in dest.parents for v in inputs.values()):
        raise ValueError('Output must be outside release and original input folders')
    rid=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_FROZEN_R01_'+uuid.uuid4().hex[:8]
    out=dest/'private'/rid; out.mkdir(parents=True,exist_ok=False)
    manifest={'run_id':rid,'started_at':datetime.now(timezone.utc).isoformat(),'status':'running','economic_repairs':[],'outputs_private':True,'command':sys.argv,'python':sys.version}
    checks=[]
    try:
        prov=json.loads((ROOT/'provenance.json').read_text(encoding='utf-8'))
        manifest['inputs']={k:{'path':v,'sha256':sha(Path(v))} for k,v in inputs.items()}
        for k,row in prov['raw_inputs'].items():
            if manifest['inputs'][k]['sha256']!=row['sha256']: raise ValueError('Different data vintage: '+k)
        deps={}
        for line in (ROOT/'requirements.lock').read_text().splitlines():
            if '==' in line:
                name,version=line.split('=='); deps[name]=importlib.metadata.version(name)
                if deps[name]!=version: raise ValueError('Dependency version mismatch: '+name)
        manifest['dependencies']=deps
        cfg=json.loads((ROOT/'config/baseline.json').read_text())
        manifest['configuration']=cfg
        snap=out/'source'; snap.mkdir()
        code=[ROOT/'run_research.py',ROOT/'requirements.lock',ROOT/'config/baseline.json']+list((ROOT/'engine').glob('*.py'))
        manifest['source_hashes']={p.relative_to(ROOT).as_posix():sha(p) for p in code}
        for p in code:
            target=snap/p.relative_to(ROOT); target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,target)
        clean=data.load_and_clean({'raw_files':inputs},cfg); p=portfolios.build(clean,cfg)
        reg,coeff=statistics.regressions(p['p25'],p['factors'],cfg)
        grs=statistics.grs_table(p['p25'],p['factors'],'exact')
        outputs=statistics.summary_tables(reg,p['factors'],grs)
        outputs.update({'grs_legacy.csv':statistics.grs_table(p['p25'],p['factors'],'legacy'),'coefficient_statistics.csv':coeff,'ff3_factor_monthly.csv':p['factors'].reset_index(),'six_2x3_portfolios.csv':p['six'].reset_index(),'test_25_portfolios.csv':p['p25'].reset_index(),'six_portfolio_monthly_stock_counts.csv':p['long6'],'test25_monthly_stock_counts.csv':p['long25']})
        tables=out/'aggregates'; tables.mkdir()
        for name,actual in outputs.items():
            actual.to_csv(tables/name,index=False)
            expected_path=ROOT/'tables'/name
            if not expected_path.exists(): continue
            a=pd.read_csv(tables/name,float_precision='round_trip'); b=pd.read_csv(expected_path,float_precision='round_trip')
            if a.shape!=b.shape or list(a.columns)!=list(b.columns): raise ValueError('Shape/column mismatch: '+name)
            for c in a:
                if pd.api.types.is_numeric_dtype(b[c]):
                    atol=cfg['tolerances']['large_sum_atol'] if c in ['weighted_ret_sum','weight_sum'] else (cfg['tolerances']['stat_atol'] if c in ['alpha_t','alpha_p','HAC_statistic','HAC_p_normal','OLS_t','OLS_p_student'] else cfg['tolerances']['value_atol'])
                    rtol=cfg['tolerances']['large_sum_rtol'] if c in ['weighted_ret_sum','weight_sum'] else 0
                    ok=np.allclose(a[c],b[c],atol=atol,rtol=rtol,equal_nan=True)
                    finite=abs(a[c]-b[c]).dropna()
                    checks.append({'table':name,'column':c,'passed':bool(ok),'n':len(a),'max_abs_error':float(finite.max()) if len(finite) else 0,'atol':atol,'rtol':rtol})
                else: checks.append({'table':name,'column':c,'passed':a[c].equals(b[c]),'n':len(a)})
        for label,k,width in [('six','six',6),('25','p25',25),('factor','factors',8)]:
            df=p[k]; checks.append({'check':label+':calendar/finite/columns','passed':df.index.astype(str).tolist()==pd.period_range('2017-07','2024-11',freq='M').astype(str).tolist() and np.isfinite(df.to_numpy()).all().item() and len(df.columns)==width})
        checks.append({'check':'all100_regressions','passed':len(reg)==100 and reg.nobs.eq(89).all().item()})
        manifest['member_counts']={'formation_stock_years':len(p['formation']),'assigned_returns':len(p['assigned']),'valid_returns':len(p['valid'])}
        # These remain private and are never copied by the publication allowlist.
        p['formation'].to_csv(out/'formation.csv',index=False); p['valid'].to_csv(out/'holdings.csv',index=False)
        manifest['status']='passed' if all(c['passed'] for c in checks) else 'failed'
        manifest['output_hashes']={q.relative_to(out).as_posix():sha(q) for q in out.rglob('*') if q.is_file()}
    except Exception:
        manifest['status']='failed'; manifest['error']=traceback.format_exc()
    manifest['completed_at']=datetime.now(timezone.utc).isoformat()
    (out/'checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    (out/'run_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'run.log').write_text(f"{manifest['started_at']} start\n{manifest['completed_at']} {manifest['status']}\n"+manifest.get('error',''),encoding='utf-8')
    print(json.dumps({'run_id':rid,'status':manifest['status'],'checks':len(checks),'failures':[c for c in checks if not c['passed']],'path':str(out),'error':manifest.get('error')},ensure_ascii=False))
    return 0 if manifest['status']=='passed' else 1


if __name__=='__main__': raise SystemExit(main())
