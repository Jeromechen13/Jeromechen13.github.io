"""Independent numerical acceptance using only public aggregate tables.

HAC is computed from matrix score products, not the research engine.
GRS uses denominator-T and Hotelling forms, independent of engine.statistics.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import norm, f
from statsmodels.stats.multitest import multipletests
from inference import build, adjusted_pvalues


def verify(root):
    root=Path(root); t=root/'tables'; checks=[]
    def check(name, condition, **detail):
        checks.append(dict(check=name,passed=bool(condition),**detail))
    def close(name, actual, expected, atol=1e-10):
        actual,expected=np.asarray(actual,float),np.asarray(expected,float)
        check(name,actual.shape==expected.shape and np.allclose(actual,expected,rtol=0,atol=atol,equal_nan=True),max_abs_error=float(np.nanmax(abs(actual-expected))),atol=atol)
    read=lambda n:pd.read_csv(t/n,float_precision='round_trip')
    fac=read('ff3_factor_monthly.csv').set_index('month')
    six=read('six_2x3_portfolios.csv').set_index('month')
    p25=read('test_25_portfolios.csv').set_index('month')
    calendar=pd.period_range('2017-07','2024-11',freq='M').astype(str).tolist()
    for name,df,width in [('six',six,6),('p25',p25,25),('factor',fac,8)]:
        check(name+':calendar',df.index.tolist()==calendar)
        check(name+':finite',np.isfinite(df.to_numpy()).all())
        check(name+':columns',len(df.columns)==width)
    close('SMB:six_identity',fac.SMB,(six.SL+six.SN+six.SH-six.BL-six.BN-six.BH)/3)
    close('HML:six_identity',fac.HML,(six.SH+six.BH-six.SL-six.BL)/2)
    for n,key,k in [('six_portfolio_monthly_stock_counts.csv','port_2x3',6),('test25_monthly_stock_counts.csv','port_5x5',25)]:
        c=read(n)
        check(n+':rows',len(c)==89*k and not c.duplicated(['month',key]).any())
        check(n+':positive_integer_counts',((c.n_stocks>0)&(c.n_stocks%1==0)).all())
        close(n+':return_identity',c.ret,c.weighted_ret_sum/c.weight_sum)
        expected=(six if k==6 else p25).stack()
        close(n+':wide',c.set_index(['month',key]).ret.reindex(expected.index),expected)
    reg=read('capm_ff3_hac_regressions_all_rf_conventions.csv')
    coeff=read('coefficient_statistics.csv')
    grs=read('grs_test.csv').set_index(['rf_convention','model'])
    legacy=read('grs_legacy.csv').set_index(['rf_convention','model'])
    for conv in ['start','end']:
        rf='rf' if conv=='start' else 'rf_end'; mk='MKT_RF' if conv=='start' else 'MKT_RF_end'
        close(conv+':market_excess',fac[mk],fac.mkt_ret-fac[rf])
        for model in ['CAPM','FF3']:
            cols=[mk] if model=='CAPM' else [mk,'SMB','HML']
            F=fac[cols].to_numpy(); Y=p25.to_numpy()-fac[rf].to_numpy()[:,None]
            T,N=Y.shape; K=len(cols); X=np.column_stack([np.ones(T),F]); nu=T-K-1
            Q,R=np.linalg.qr(X); B=np.linalg.solve(R,Q.T@Y); E=Y-X@B
            bread=np.linalg.solve(X.T@X,np.eye(K+1))
            for j,asset in enumerate(p25.columns):
                z=X*E[:,j,None]; meat=z.T@z
                for lag in range(1,7):
                    cross=z[lag:].T@z[:-lag]; meat+=(1-lag/7)*(cross+cross.T)
                se=np.sqrt(np.diag(bread@meat@bread)); zstat=B[:,j]/se
                c=coeff[(coeff.portfolio==asset)&(coeff.model==model)&(coeff.rf_convention==conv)].set_index('parameter').loc[['const']+cols]
                label=f'{conv}:{model}:{asset}'
                close(label+':coef',B[:,j],c.coefficient)
                close(label+':HAC_se',se,c.HAC_se)
                close(label+':normal_p',2*norm.sf(abs(zstat)),c.HAC_p_normal,1e-8)
                close(label+':CI',np.column_stack([B[:,j]-norm.ppf(.975)*se,B[:,j]+norm.ppf(.975)*se]),c[['ci_lower','ci_upper']])
                adj=1-(E[:,j]@E[:,j])/((Y[:,j]-Y[:,j].mean())@(Y[:,j]-Y[:,j].mean()))*(T-1)/nu
                row=reg[(reg.portfolio==asset)&(reg.model==model)&(reg.rf_convention==conv)].iloc[0]
                close(label+':adj_r2',[adj],[row.adj_r2])
            mu=F.mean(axis=0); Fc=F-mu; se0=E.T@E/T; sf0=Fc.T@Fc/T
            a=B[0]; exact=(T-N-K)/N*(a@np.linalg.solve(se0,a))/(1+mu@np.linalg.solve(sf0,mu))
            se=E.T@E/nu; sf=Fc.T@Fc/(T-1); c=bread[0,0]
            hotelling=(nu-N+1)/(N*nu*c)*(a@np.linalg.solve(se,a))
            old=T/N*(T-N-K)/nu*(a@np.linalg.solve(se,a))/(1+mu@np.linalg.solve(sf,mu))
            close(conv+model+':GRS_ML',[exact],[grs.loc[(conv,model),'GRS']])
            close(conv+model+':GRS_Hotelling',[hotelling],[exact])
            close(conv+model+':GRS_legacy',[old],[legacy.loc[(conv,model),'GRS']])
            close(conv+model+':GRS_p',[f.sf(exact,N,T-N-K)],[grs.loc[(conv,model),'p_value']])
            t2=a*a/(np.diag(se)*c)
            n1=(T-1-K)*a*a/np.diag(se0)/(1+mu@np.linalg.solve(sf0,mu))
            close(conv+model+':N1_OLS_t2',n1,t2)
    alpha,counts=build(t)
    saved=read('alpha_inference.csv')
    check('alpha:keys',alpha[['portfolio','model','rf_convention']].equals(saved[['portfolio','model','rf_convention']]))
    for col in alpha.select_dtypes(include=[np.number]).columns:
        close('alpha:saved:'+col,alpha[col],saved[col],1e-14)
    for (conv,model),g in alpha.groupby(['rf_convention','model']):
        for method, col in [('holm','holm_p'),('fdr_bh','bh_p')]:
            close(conv+model+':'+method,g[col],multipletests(g.alpha_p,method=method)[1],1e-14)
    # Boundary values, ties and order preservation; different from actual-data-only tests.
    edge=np.array([1.,0.,.01,.01,.04,.9])
    for actual,method in zip(adjusted_pvalues(edge),['holm','fdr_bh']):
        close('multiplicity:ties:'+method,actual,multipletests(edge,method=method)[1],1e-14)
    ci_excludes=(alpha.ci95_lower>0)|(alpha.ci95_upper<0)
    check('pointwise_CI_duality',np.array_equal(ci_excludes,alpha.unadjusted_reject_5pct))
    check('saved_counts',counts.equals(read('multiplicity_summary.csv')))
    # Independent factor mean HAC using score autocovariances.
    display=json.loads((root/'display.json').read_text(encoding='utf-8'))
    for col,label in [('MKT_RF','MKT − RF'),('SMB','SMB'),('HML','HML')]:
        y=fac[col].to_numpy(); u=y-y.mean(); v=u@u
        for lag in range(1,7): v+=2*(1-lag/7)*(u[lag:]@u[:-lag])
        se=np.sqrt(v)/len(y); row=next(x for x in display['factor_stats'] if x['factor']==label)
        close(label+':mean_HAC',[y.mean()*100,se*100,2*norm.sf(abs(y.mean()/se))],[row['mean_pct'],row['hac_se_pct'],row['hac_p']])
    prov=json.loads((root/'provenance.json').read_text(encoding='utf-8'))
    for path,row in prov['copied_inputs'].items():
        check('source_hash:'+path,hashlib.sha256((root/path).read_bytes()).hexdigest()==row['sha256'])
    return {'passed':all(c['passed'] for c in checks),'checks':checks,'count':len(checks),'failures':[c for c in checks if not c['passed']]}


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--root',type=Path,default=Path(__file__).parent); p.add_argument('--out',type=Path)
    args=p.parse_args(); result=verify(args.root)
    if args.out:
        with args.out.open('x',encoding='utf-8') as f: json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
    raise SystemExit(0 if result['passed'] else 1)
