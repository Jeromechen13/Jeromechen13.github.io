# 可复现运行与发布边界

## 无需原始数据的核验

使用 CPython 3.12.4，依赖版本见 `requirements.lock`（现有环境版本锁，不是二进制镜像）。从 `release/` 运行：

```powershell
python -B -X utf8 verify.py --out "$env:TEMP/ff3-verification-unique.json"
python -B -X utf8 inference.py --tables tables --out "$env:TEMP/ff3-inference-unique"
```

输出路径必须不存在。验证全部月度六组合/25组合、因子恒等式、100 回归的独立 QR 系数/Bartlett HAC、精确/legacy GRS、Hotelling、N=1 普通 OLS t²、多重检验及区间。只比较既有聚合数据，不需要或反推股票级数据。

## 持有授权数据时从四表重建

`engine/` 三个核心模块逐字复制自已验收 R01 的源码快照；适配入口只负责路径、运行记录和比对，不修改模型规则。输入 JSON 自行放在**仓库外**，键为 stock、finance、market、rf，值为四张 CSV 的绝对路径。例如：

```json
{"stock":"E:/licensed/TRD_Mnth.csv","finance":"E:/licensed/FS_Combas.csv","market":"E:/licensed/TRD_Cnmont.csv","rf":"E:/licensed/TRD_Nrrate.csv"}
```

```powershell
python -B -X utf8 run_research.py --inputs E:/licensed/inputs.json --out E:/ff3-local-runs
```

入口先检查数据 SHA-256 和依赖版本。不同数据 vintage 将失败，不能把“另外一次下载”宣称为原数值严格复现。每次写入新 `private/<UTC_FROZEN_R01_UUID>/`，含源代码快照、输入/输出哈希、run_manifest、日志、逐列逐值验收和股票级形成/持有表；不得上传整个运行目录。不会覆盖旧输出或运行原 Notebook。

容差沿用 R00/R01：通常值绝对误差 1e−10，统计量 1e−8，大额加权和 1e−5 加相对误差 1e−13；键、月份、行数、整数计数必须一致。最终版未放宽容差。局部失败或异常保留 failed manifest，不能删除后假装从未发生。

原研究结果位于仓库 `output/`，是历史 v7/legacy，不再作为网页 GRS 来源。原 Notebook 不变，不建议执行其覆盖原 output 的导出单元。R00/R01 原始运行均留在独立工作区，公开 provenance 记录对应 run_id、manifest 哈希和安全聚合输入哈希，绝对私人路径不公开。

## 图表与网页

研究包可独立生成五张 FF3 图：在 `release/` 运行 `python -B plot_figures.py --out <不存在的新目录>`。另需 `visualization.requirements.lock` 的绘图依赖。该入口只读取公开聚合表，输出与仓库 FF3 绘图函数一致，不包含其他项目的代码或本机路径。字体缺失时使用后备字体；数值应一致，但不同环境下 SVG 字节不保证一致。

仓库根目录运行 `python -B scripts/build_figures.py --project ff3`，只生成 FF3 五张图及复制已核验 `release/display.json`。统计推断源为 `tables/alpha_inference.csv`、`tables/grs_test.csv`；旧版 GRS 另表保存。图表显示单位为百分比、bp 或无单位，因子连乘是展示指数而非可投资净值。

然后在 `quant-research/` 运行 `npm run build`，Astro 依赖由已有 package-lock.json 锁定；构建同时校验离线相对链接。页面、首页摘要和研究列表读取统一 JSON。本地静态构建不等同于已部署远端。

## 公开文件边界

仅 `PUBLIC_ALLOWLIST.json` 指明的精确路径可进入 FF3 研究包。公开内容为本文档、可移植源码/配置、聚合收益与统计表、图表/页面、来源与验收摘要。未提供数据的再分发授权，不包含原始 CSMAR、证券代码/逐股票数据、audit/private 内容、公告 PDF、论文全文或供应商手册。公开选择不授予第三方对底层商业数据库的使用权。

`package_public.py` 验证所有列明文件的 SHA-256，再复制到一个不存在的新目录并生成 zip。未知新增文件不会自动纳入。原始 Notebook、原结果、完整审计和已验收运行仍留本地原位置；不复制整个项目或工作区。根目录旧批量打包入口将拒绝未经允许清单审核的递归复制。
