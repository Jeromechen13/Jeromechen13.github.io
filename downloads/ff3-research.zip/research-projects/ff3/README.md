# A 股 Fama–French 三因子：构建、检验与研究审计

这是采用年度独立排序的 A 股样本内实证研究。原四张 CSMAR CSV、原 Notebook 和历史输出保持不变；R00 完整复现旧规则，R01 仅修正 GRS 有限样本归一化。最终版补充 Holm/BH、HAC 标准误与区间，统一网页和文档。

**可复现计算与统计披露已完成；H1–H4 经济数据限制尚未修复，不能称为严格 FF1993 复刻、无前视偏差的定价认证或可交易策略。** 研究范围已冻结，无新增外部数据或定价模型。

研究期 2017-07—2024-11，89 月；沪深 A 股（含创业板、科创板）；六个因子构建组合、25 个测试组合、两模型和两种 RF 口径共 100 回归。

| 模型 | 平均调整 R² | 平均 \|α\|（%/月） | 未校正 / Holm / BH | Exact GRS | p |
|---|---:|---:|---:|---:|---:|
| CAPM | 68.827651% | 0.243607 | 0 / 0 / 0 | 1.648048075 | 0.056863467 |
| FF3 | 93.297531% | 0.196260 | 5 / 0 / 2 | 1.675162569 | 0.052350258 |

主规格为月初 RF / Bartlett HAC(6) / 正态近似。FF3 五个名义显著 alpha，Holm 后为零；BH 的两个是探索性发现，依赖性条件未认证。所有区间为单项区间。GRS 两模型在 5% 水平均未拒绝，不等于证明正确风险定价。SMB/HML 月均分别为 0.077259% / 0.225767%，HAC p 为 0.866006 / 0.579969，样本未提供显著非零均值证据。

## 阅读与复现

- [方法、公式、数据字段和筛选规则](release/METHODS.md)
- [完整主要结果与统计表](release/RESULTS.md)
- [H1–H4 限制与既有敏感性诊断](release/LIMITATIONS.md)
- [可复现运行与发布边界](release/REPRODUCIBILITY.md)
- [数据和源码来源记录](release/provenance.json)
- [数值验收记录](release/NUMERICAL_ACCEPTANCE.json)
- [公开文件允许清单](release/PUBLIC_ALLOWLIST.json)

在 `release/` 下运行 `python -B -X utf8 verify.py` 可仅用公开聚合表独立验证。持有相同授权四表时，使用 `run_research.py --inputs <仓库外JSON> --out <仓库外目录>` 从原始数据重建，依赖版本锁见 `requirements.lock`。结果写入唯一私有 run_id。详细命令见运行说明。

网页源文件为 `quant-research/src/pages/research/ff3.astro`；网页读取最终 `display.json`，图表读取 R01 聚合表。仓库根执行 `python -B scripts/build_figures.py --project ff3`，再在 `quant-research` 执行 `npm run build`。本地入口为 `quant-research/dist/research/ff3.html`。

## 版本与保护

原 `Ashare_FF3_Empirical_Asset_Pricing_v7.ipynb` 和 `output/` 仅作为历史 baseline 保留，含 legacy GRS；不要把原输出误认作最终展示统计，也不要覆盖运行。最终估计来自 `20261015T080033Z_R01_a90541c5`；本轮 `20261015T092404Z_FINAL_f60e697a`。已验收 R00/R01 与阶段一至四的完整证据保存在原位置，不因展示更新而改写。

只公开允许清单内的源码、配置、聚合结果和说明。原始 CSMAR、股票级台账、audit/private、原报与修订报 PDF、受限字段手册或论文不进入公开包。历史审计文件夹是本地证据，不是公开附件。旧递归打包入口已禁用；使用 `release/package_public.py` 生成校验过的新包。
